package com.nttdata.democuentas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCuentasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCuentasApplication.class, args);
	}

}
