package com.nttdata.democuentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCuentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
